package com.edupablo.misrecordatorios2;

public class Tarea {
    private int id;
    private String nombre;
    private String descripcion;
    private String fecha;
    private double coste;
    private boolean urgente;
    private boolean completada;

    // Constructor completo, incluyendo ID
    public Tarea(int id, String nombre, String descripcion, String fecha, double coste, boolean urgente, boolean completada) {
        this(nombre, descripcion, fecha, coste, urgente, completada); // Reutiliza el otro constructor
        this.id = id;
    }

    // Constructor sin ID
    public Tarea(String nombre, String descripcion, String fecha, double coste, boolean urgente, boolean completada) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.coste = coste;
        this.urgente = urgente;
        this.completada = completada;
    }

    // Getters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public String getFecha() { return fecha; }
    public double getCoste() { return coste; }
    public boolean isUrgente() { return urgente; }
    public boolean isCompletada() { return completada; }

    public void setId(int id) { this.id = id; }
}
