package com.edupablo.misrecordatorios2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "tareas.db";
    private static final int DATABASE_VERSION = 3; // Incrementamos la versión para activar onUpgrade

    // Nombres de tablas y columnas
    public static final String TABLE_TAREAS = "tareas";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NOMBRE = "nombre";
    public static final String COLUMN_DESCRIPCION = "descripcion";
    public static final String COLUMN_FECHA = "fecha";
    public static final String COLUMN_COSTE = "coste";
    public static final String COLUMN_URGENTE = "urgente";
    public static final String COLUMN_COMPLETADA = "completada"; // 0 = pendiente, 1 = hecha

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_TAREAS + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NOMBRE + " TEXT, " +
                COLUMN_DESCRIPCION + " TEXT, " +
                COLUMN_FECHA + " TEXT, " +
                COLUMN_COSTE + " REAL, " +
                COLUMN_URGENTE + " INTEGER DEFAULT 0, " +
                COLUMN_COMPLETADA + " INTEGER DEFAULT 0)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_TAREAS + " ADD COLUMN " + COLUMN_URGENTE + " INTEGER DEFAULT 0");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE " + TABLE_TAREAS + " ADD COLUMN " + COLUMN_NOMBRE + " TEXT DEFAULT ''");
        }
    }

    // Método para agregar una tarea con los nuevos atributos
    public void agregarTarea(Tarea tarea) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOMBRE, tarea.getNombre());
        values.put(COLUMN_DESCRIPCION, tarea.getDescripcion());
        values.put(COLUMN_FECHA, tarea.getFecha());
        values.put(COLUMN_COSTE, tarea.getCoste());
        values.put(COLUMN_URGENTE, tarea.isUrgente() ? 1 : 0);
        values.put(COLUMN_COMPLETADA, tarea.isCompletada() ? 1 : 0);
        db.insert(TABLE_TAREAS, null, values);
        db.close();
        Log.d("DBHelper", "Tarea agregada: " + tarea.getNombre() + " | Urgente: " + (tarea.isUrgente() ? "Sí" : "No"));
    }

    // Método para obtener todas las tareas, pendientes o completadas
    public ArrayList<Tarea> obtenerTareas(boolean completada) {
        ArrayList<Tarea> tareas = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_TAREAS + " WHERE " + COLUMN_COMPLETADA + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{completada ? "1" : "0"});
        if (cursor.moveToFirst()) {
            do {
                Tarea tarea = new Tarea(
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOMBRE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPCION)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FECHA)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_COSTE)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_URGENTE)) == 1,
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_COMPLETADA)) == 1
                );
                tareas.add(tarea);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return tareas;
    }

    // Método para obtener una tarea por su ID
    public Tarea obtenerTareaPorId(int tareaId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Tarea tarea = null;

        Cursor cursor = db.query(TABLE_TAREAS, null, COLUMN_ID + " = ?", new String[]{String.valueOf(tareaId)}, null, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                // Verificar cada columna por si acaso no existe en la tabla
                int nombreIndex = cursor.getColumnIndex(COLUMN_NOMBRE);
                int descripcionIndex = cursor.getColumnIndex(COLUMN_DESCRIPCION);
                int fechaIndex = cursor.getColumnIndex(COLUMN_FECHA);
                int costeIndex = cursor.getColumnIndex(COLUMN_COSTE);
                int urgenteIndex = cursor.getColumnIndex(COLUMN_URGENTE);
                int completadaIndex = cursor.getColumnIndex(COLUMN_COMPLETADA);

                // Verificar que los índices son válidos antes de acceder a las columnas
                String nombre = (nombreIndex != -1) ? cursor.getString(nombreIndex) : "Nombre no disponible";
                String descripcion = (descripcionIndex != -1) ? cursor.getString(descripcionIndex) : "Descripción no disponible";
                String fecha = (fechaIndex != -1) ? cursor.getString(fechaIndex) : "Fecha no disponible";
                double coste = (costeIndex != -1) ? cursor.getDouble(costeIndex) : 0.0;
                boolean urgente = (urgenteIndex != -1) && (cursor.getInt(urgenteIndex) == 1);
                boolean completada = (completadaIndex != -1) && (cursor.getInt(completadaIndex) == 1);

                // Crear la tarea con los datos obtenidos
                tarea = new Tarea(nombre, descripcion, fecha, coste, urgente, completada);
                tarea.setId(tareaId); // Asegúrate de establecer el ID
            }
            cursor.close();
        }

        return tarea;
    }


    // Marcar tarea como hecha
    public void marcarTareaHecha(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COMPLETADA, 1);
        db.update(TABLE_TAREAS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
        Log.d("DBHelper", "Tarea marcada como hecha con ID: " + id);
    }

    // Eliminar tarea por ID en lugar de por nombre
    public void eliminarTarea(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_TAREAS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
        Log.d("DBHelper", "Tarea eliminada con ID: " + id);
    }
}
