package com.edupablo.misrecordatorios2;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroTareasActivity extends AppCompatActivity {

    private EditText editNombre, editDescripcion, editFecha, editCoste;
    private Spinner spinnerUrgencia;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_tareas);

        editNombre = findViewById(R.id.editNombre);
        editDescripcion = findViewById(R.id.editDescripcion);
        editFecha = findViewById(R.id.editFecha);
        editCoste = findViewById(R.id.editCoste);
        spinnerUrgencia = findViewById(R.id.spinnerUrgencia);
        Button buttonRegistrar = findViewById(R.id.buttonRegistrar);
        Button buttonCancelar = findViewById(R.id.buttonCancelar);

        dbHelper = new DBHelper(this);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.urgencia_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerUrgencia.setAdapter(adapter);

        buttonRegistrar.setOnClickListener(v -> guardarTarea());

        buttonCancelar.setOnClickListener(v -> finish()); // Cierra esta actividad y vuelve a MainActivity
    }

    private void guardarTarea() {
        String nombre = editNombre.getText().toString().trim();
        String descripcion = editDescripcion.getText().toString().trim();
        String fecha = editFecha.getText().toString().trim();
        String costeInput = editCoste.getText().toString().trim();

        if (TextUtils.isEmpty(nombre)) {
            editNombre.setError("El nombre no puede estar vacío");
            return;
        }
        if (TextUtils.isEmpty(descripcion)) {
            editDescripcion.setError("La descripción no puede estar vacía");
            return;
        }
        if (TextUtils.isEmpty(fecha)) {
            editFecha.setError("La fecha no puede estar vacía");
            return;
        }
        if (TextUtils.isEmpty(costeInput)) {
            editCoste.setError("El coste no puede estar vacío");
            return;
        }

        double coste;
        try {
            coste = Double.parseDouble(costeInput);
        } catch (NumberFormatException e) {
            editCoste.setError("Introduce un valor numérico válido para el coste");
            return;
        }

        String urgenciaSeleccionada = spinnerUrgencia.getSelectedItem().toString();
        boolean esUrgente = urgenciaSeleccionada.equals("Urgente");

        Tarea nuevaTarea = new Tarea(nombre, descripcion, fecha, coste, esUrgente, false);
        dbHelper.agregarTarea(nuevaTarea);

        Toast.makeText(this, "Tarea guardada correctamente", Toast.LENGTH_SHORT).show();
        finish();
    }
}
