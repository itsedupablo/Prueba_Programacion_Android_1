package com.edupablo.misrecordatorios2;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class InfoTareaActivity extends AppCompatActivity {

    private TextView textNombre, textDescripcion, textFecha, textCoste, textUrgente, textCompletada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_tareas);

        textNombre = findViewById(R.id.textNombre);
        textDescripcion = findViewById(R.id.textDescripcion);
        textFecha = findViewById(R.id.textFecha);
        textCoste = findViewById(R.id.textCoste);
        textUrgente = findViewById(R.id.textUrgente);
        textCompletada = findViewById(R.id.textCompletada);

        // Configurar el botón de "Atrás" en la barra de acción
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Suponiendo que recibes el objeto tarea a través de un intent
        Tarea tarea = obtenerTareaDesdeIntent();

        if (tarea != null) {
            textNombre.setText(tarea.getNombre());
            textDescripcion.setText(tarea.getDescripcion());
            textFecha.setText(tarea.getFecha());
            textCoste.setText(String.format("$%.2f", tarea.getCoste()));

            // Mostrar "Urgente" o "No urgente" según el valor booleano
            textUrgente.setText(tarea.isUrgente() ? "Urgente" : "No urgente");
            textCompletada.setText(tarea.isCompletada() ? "Completada" : "Pendiente");
        } else {
            // En caso de que la tarea sea nula, puedes mostrar un mensaje de error
            textNombre.setText("Error: Tarea no encontrada");
        }
    }

    private Tarea obtenerTareaDesdeIntent() {
        int tareaId = getIntent().getIntExtra("tarea_id", -1);
        if (tareaId == -1) {
            return null; // Si el ID es inválido, retorna null
        }

        DBHelper dbHelper = new DBHelper(this);
        return dbHelper.obtenerTareaPorId(tareaId); // Método que debería obtener la tarea desde la base de datos
    }

    // Manejar el evento de clic en el botón de "Atrás" en la barra de acción
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Cierra InfoTareaActivity y vuelve a MainActivity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
 