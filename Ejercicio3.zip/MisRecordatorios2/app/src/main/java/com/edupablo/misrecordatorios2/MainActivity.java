package com.edupablo.misrecordatorios2;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private ArrayAdapter<String> adapter;
    private ListView listViewTareas;
    private boolean mostrandoPendientes = true;
    private ArrayList<Tarea> listaTareasCompleta; // Lista auxiliar para almacenar las tareas completas

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
        listViewTareas = findViewById(R.id.listViewTareas);
        Button buttonAgregar = findViewById(R.id.buttonAgregar);
        Button buttonPendientes = findViewById(R.id.buttonPendientes);
        Button buttonCompletadas = findViewById(R.id.buttonCompletadas);

        mostrandoPendientes = true;
        cargarNombresDeTareas(); // Carga solo los nombres de las tareas
        registerForContextMenu(listViewTareas);

        buttonAgregar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegistroTareasActivity.class);
            startActivity(intent);
        });

        buttonPendientes.setOnClickListener(v -> {
            mostrandoPendientes = true;
            cargarNombresDeTareas();
            Toast.makeText(this, "Mostrando tareas pendientes", Toast.LENGTH_SHORT).show();
        });

        buttonCompletadas.setOnClickListener(v -> {
            mostrandoPendientes = false;
            cargarNombresDeTareas();
            Toast.makeText(this, "Mostrando tareas completadas", Toast.LENGTH_SHORT).show();
        });
    }

    private void cargarNombresDeTareas() {
        listaTareasCompleta = dbHelper.obtenerTareas(mostrandoPendientes); // Almacenar todas las tareas completas
        ArrayList<String> nombresTareas = new ArrayList<>();

        // Extraer solo los nombres de las tareas para mostrar en el ListView
        for (Tarea tarea : listaTareasCompleta) {
            nombresTareas.add(tarea.getNombre());
        }

        // Crear un adaptador con solo los nombres
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, nombresTareas);
        listViewTareas.setAdapter(adapter);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        if (info == null) return super.onContextItemSelected(item);

        // Obtener la tarea seleccionada usando la posición del item en `listaTareasCompleta`
        Tarea tareaSeleccionada = listaTareasCompleta.get(info.position);
        if (tareaSeleccionada == null) return super.onContextItemSelected(item);

        if (item.getItemId() == R.id.done) {
            dbHelper.marcarTareaHecha(tareaSeleccionada.getId());
            cargarNombresDeTareas();
            Toast.makeText(this, "Tarea marcada como hecha", Toast.LENGTH_SHORT).show();
            return true;
        } else if (item.getItemId() == R.id.delete) {
            dbHelper.eliminarTarea(tareaSeleccionada.getId());
            cargarNombresDeTareas();
            Toast.makeText(this, "Tarea eliminada", Toast.LENGTH_SHORT).show();
            return true;
        } else if (item.getItemId() == R.id.info) {
            // Lanza InfoTareaActivity y pasa el ID de la tarea seleccionada
            Intent intent = new Intent(MainActivity.this, InfoTareaActivity.class);
            intent.putExtra("tarea_id", tareaSeleccionada.getId());
            startActivity(intent);
            return true;
        } else {
            return super.onContextItemSelected(item);
        }
    }
}
