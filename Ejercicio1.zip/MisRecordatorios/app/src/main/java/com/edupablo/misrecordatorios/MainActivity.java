package com.edupablo.misrecordatorios;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private ArrayAdapter<String> adapterPendientes;
    private ArrayAdapter<String> adapterHechas;
    private ListView listViewTareas;
    private boolean mostrandoPendientes = true; // Control de vista

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
        listViewTareas = findViewById(R.id.listViewTareas);
        EditText editTextTarea = findViewById(R.id.editTextTarea);
        Button buttonAgregar = findViewById(R.id.buttonAgregar);
        Button buttonPendientes = findViewById(R.id.buttonPendientes);
        Button buttonCompletadas = findViewById(R.id.buttonCompletadas);

        cargarTareas();  // Cargar tareas desde la base de datos
        registerForContextMenu(listViewTareas); // Menú contextual

        buttonAgregar.setOnClickListener(v -> {
            String tarea = editTextTarea.getText().toString();
            if (!tarea.isEmpty()) {
                dbHelper.agregarTarea(tarea, false);  // Guardar en base de datos como pendiente
                cargarTareas();
                editTextTarea.setText("");
            }
        });

        buttonPendientes.setOnClickListener(v -> {
            mostrandoPendientes = true;
            cargarTareas();
            Toast.makeText(this, "Mostrando tareas pendientes", Toast.LENGTH_SHORT).show();
        });

        buttonCompletadas.setOnClickListener(v -> {
            mostrandoPendientes = false;
            cargarTareas();
            Toast.makeText(this, "Mostrando tareas completadas", Toast.LENGTH_SHORT).show();
        });
    }

    private void cargarTareas() {
        ArrayList<String> tareas = dbHelper.obtenerTareas(mostrandoPendientes);
        if (mostrandoPendientes) {
            adapterPendientes = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tareas);
            listViewTareas.setAdapter(adapterPendientes);
        } else {
            adapterHechas = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tareas);
            listViewTareas.setAdapter(adapterHechas);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu); // Menú contextual
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        String tarea = ((ArrayAdapter<String>) listViewTareas.getAdapter()).getItem(info.position);

        if (item.getItemId() == R.id.mark_done) {
            dbHelper.marcarTareaHecha(tarea); // Actualizar en base de datos
            cargarTareas();
            Toast.makeText(this, "Tarea marcada como hecha", Toast.LENGTH_SHORT).show();
            return true;
        } else if (item.getItemId() == R.id.delete_task) {
            dbHelper.eliminarTarea(tarea); // Eliminar en base de datos
            cargarTareas();
            Toast.makeText(this, "Tarea eliminada", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onContextItemSelected(item);
    }
}
