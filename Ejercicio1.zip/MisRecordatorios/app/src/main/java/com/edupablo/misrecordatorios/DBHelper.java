package com.edupablo.misrecordatorios;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "tareas.db";
    private static final int DATABASE_VERSION = 1;

    // Nombres de tablas y columnas
    public static final String TABLE_TAREAS = "tareas";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_DESCRIPCION = "descripcion";
    public static final String COLUMN_COMPLETADA = "completada"; // 0 = pendiente, 1 = hecha

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_TAREAS + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DESCRIPCION + " TEXT, " +
                COLUMN_COMPLETADA + " INTEGER)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TAREAS);
        onCreate(db);
    }

    // Agregar tarea
    public void agregarTarea(String descripcion, boolean completada) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DESCRIPCION, descripcion);
        values.put(COLUMN_COMPLETADA, completada ? 1 : 0);
        db.insert(TABLE_TAREAS, null, values);
        db.close();
    }

    // Obtener todas las tareas, pendientes o completadas
    public ArrayList<String> obtenerTareas(boolean completada) {
        ArrayList<String> tareas = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_DESCRIPCION + " FROM " + TABLE_TAREAS +
                " WHERE " + COLUMN_COMPLETADA + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{completada ? "1" : "0"});
        if (cursor.moveToFirst()) {
            do {
                tareas.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return tareas;
    }

    // Marcar tarea como hecha
    public void marcarTareaHecha(String descripcion) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COMPLETADA, 1);
        db.update(TABLE_TAREAS, values, COLUMN_DESCRIPCION + " = ?", new String[]{descripcion});
        db.close();
    }

    // Eliminar tarea
    public void eliminarTarea(String descripcion) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_TAREAS, COLUMN_DESCRIPCION + " = ?", new String[]{descripcion});
        db.close();
    }
}
