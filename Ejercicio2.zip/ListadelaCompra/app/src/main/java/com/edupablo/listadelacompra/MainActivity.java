package com.edupablo.listadelacompra;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private ArrayList<Producto> productos;
    private ProductoAdapter productoAdapter;
    private TextView textViewTotalProductos;
    private TextView textViewPrecioTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
        productos = dbHelper.obtenerProductos();  // Cargar productos desde la BD
        productoAdapter = new ProductoAdapter(this, productos);

        textViewTotalProductos = findViewById(R.id.textViewTotalProductos);
        textViewPrecioTotal = findViewById(R.id.textViewPrecioTotal);

        EditText editTextNombreProducto = findViewById(R.id.editTextNombreProducto);
        EditText editTextCantidad = findViewById(R.id.editTextCantidad);
        EditText editTextPrecio = findViewById(R.id.editTextPrecio);
        Button buttonAgregarProducto = findViewById(R.id.buttonAgregarProducto);
        ListView listViewProductos = findViewById(R.id.listViewProductos);
        listViewProductos.setAdapter(productoAdapter);

        // Agregar producto y guardar en BD
        buttonAgregarProducto.setOnClickListener(v -> {
            String nombre = editTextNombreProducto.getText().toString().trim();
            int cantidad = editTextCantidad.getText().toString().isEmpty() ? 1 : Integer.parseInt(editTextCantidad.getText().toString());
            double precio = editTextPrecio.getText().toString().isEmpty() ? 0 : Double.parseDouble(editTextPrecio.getText().toString());

            if (nombre.isEmpty()) {
                Toast.makeText(this, "El nombre del producto es obligatorio", Toast.LENGTH_SHORT).show();
                return;
            }

            Producto nuevoProducto = new Producto(nombre, cantidad, precio);
            dbHelper.agregarProducto(nuevoProducto);  // Guardar en BD
            productos.add(nuevoProducto);
            productoAdapter.notifyDataSetChanged();

            actualizarResumen();

            editTextNombreProducto.setText("");
            editTextCantidad.setText("");
            editTextPrecio.setText("");
        });

        actualizarResumen();
    }

    private void actualizarResumen() {
        textViewTotalProductos.setText("Total productos: " + productos.size());
        double precioTotal = dbHelper.calcularPrecioTotal();
        textViewPrecioTotal.setText("Precio total: " + precioTotal + " €");
    }
}
