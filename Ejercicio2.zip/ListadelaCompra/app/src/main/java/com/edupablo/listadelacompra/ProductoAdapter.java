package com.edupablo.listadelacompra;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ProductoAdapter extends ArrayAdapter<Producto> {

    public ProductoAdapter(Context context, ArrayList<Producto> productos) {
        super(context, 0, productos);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.producto, parent, false);
        }

        Producto producto = getItem(position);
        TextView nombreTextView = convertView.findViewById(R.id.nombreProducto);
        TextView cantidadTextView = convertView.findViewById(R.id.cantidadProducto);
        TextView precioTextView = convertView.findViewById(R.id.precioProducto);

        nombreTextView.setText(producto.getNombre());
        cantidadTextView.setText("Cantidad: " + producto.getCantidad());
        precioTextView.setText("Precio: " + (producto.tienePrecio() ? producto.getPrecio() + " €" : "-"));

        return convertView;
    }
}
